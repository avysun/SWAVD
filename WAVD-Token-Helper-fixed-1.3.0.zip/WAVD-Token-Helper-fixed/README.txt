WAVD SUNO TOKEN HELPER — FIXED v1.3.0

Why the previous version failed
-------------------------------
Suno no longer exposes window.Clerk.
A one-shot fetch to studio-api does NOT include Authorization: Bearer —
only the real Suno frontend adds that header. So intercepting only at
button-click time usually saw nothing.

What this version does
----------------------
1. Content script + injected.js (external file, CSP-safe) runs on every
   suno.com page from document_start and permanently sniffs fetch/XHR
   for Authorization: Bearer JWTs. Tokens are stored in chrome.storage.

2. On button click the popup tries, in order:
   a) last JWT captured by the sniffer
   b) read HttpOnly __client cookie from auth.suno.com and exchange it
      for a fresh JWT via Clerk API (works even if the page is idle)
   c) scan localStorage / sessionStorage / document.cookie as last resort

3. Old window.Clerk path is completely removed.

Install
-------
1. chrome://extensions → Developer mode
2. Remove any previous WAVD Token Helper
3. Load unpacked → select this folder
4. Open https://suno.com and sign in
5. Refresh the Suno tab once (so the content script + sniffer attach)
6. Start WAVD Desktop, click the extension button

Permissions
-----------
- cookies + host access to auth.suno.com / studio-api — needed to read
  __client and mint JWT
- storage — cache last captured Bearer
- nothing is sent outside 127.0.0.1 except the Clerk token exchange
  (same servers the browser already talks to)
