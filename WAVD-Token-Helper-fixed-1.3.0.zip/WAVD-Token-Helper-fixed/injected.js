/**
 * Runs in the PAGE main world (loaded as external script to bypass Suno CSP).
 * Permanently patches fetch + XHR and forwards every Authorization: Bearer JWT
 * to the content script via window.postMessage.
 */
(function () {
  if (window.__WAVD_TOKEN_SNIFFER__) return;
  window.__WAVD_TOKEN_SNIFFER__ = true;

  const JWT_RE = /^Bearer\s+(eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)/i;

  function isApiUrl(url) {
    if (!url || typeof url !== "string") return false;
    return (
      url.includes("studio-api.prod.suno.com") ||
      url.includes("studio-api-prod.suno.com") ||
      /studio-api[^/]*\.suno\.com/i.test(url)
    );
  }

  function emit(token) {
    if (!token || !token.startsWith("eyJ")) return;
    try {
      window.postMessage(
        { source: "WAVD_TOKEN_HELPER", type: "SUNO_BEARER", token },
        "*"
      );
    } catch (_) {}
  }

  function extractFromHeaders(headers) {
    if (!headers) return null;
    try {
      if (typeof headers.get === "function") {
        const auth = headers.get("Authorization") || headers.get("authorization");
        if (auth) {
          const m = auth.match(JWT_RE);
          if (m) return m[1];
        }
        return null;
      }
      if (typeof headers === "object") {
        for (const [k, v] of Object.entries(headers)) {
          if (k.toLowerCase() === "authorization" && typeof v === "string") {
            const m = v.match(JWT_RE);
            if (m) return m[1];
          }
        }
      }
    } catch (_) {}
    return null;
  }

  // --- fetch ---
  const originalFetch = window.fetch;
  window.fetch = function (...args) {
    try {
      const input = args[0];
      const init = args[1] || {};
      const url =
        typeof input === "string"
          ? input
          : input && typeof input.url === "string"
            ? input.url
            : "";
      if (isApiUrl(url)) {
        const token = extractFromHeaders(init.headers);
        if (token) emit(token);
        // Also try Request object headers
        if (!token && input && typeof input.headers !== "undefined") {
          const t2 = extractFromHeaders(input.headers);
          if (t2) emit(t2);
        }
      }
    } catch (_) {}
    return originalFetch.apply(this, args);
  };

  // --- XHR ---
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__wavdUrl = typeof url === "string" ? url : String(url);
    return originalOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    try {
      if (
        String(name).toLowerCase() === "authorization" &&
        typeof value === "string" &&
        isApiUrl(this.__wavdUrl)
      ) {
        const m = value.match(JWT_RE);
        if (m) emit(m[1]);
      }
    } catch (_) {}
    return originalSetRequestHeader.call(this, name, value);
  };
})();
