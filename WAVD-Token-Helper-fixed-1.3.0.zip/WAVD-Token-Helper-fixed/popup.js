const button = document.getElementById("copy-token");
const status = document.getElementById("status");
const WAVD_TOKEN_BRIDGE = "http://127.0.0.1:18973/v1/token";

// Clerk frontend API used by Suno (as of 2026)
const CLERK_API_VERSION = "2025-11-10";
const CLERK_JS_VERSION = "5.117.0";
const CLERK_BASE = "https://auth.suno.com";

function setStatus(message, type = "") {
  status.textContent = message;
  status.className = `status${type ? ` ${type}` : ""}`;
}

function isSunoPage(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    return hostname === "suno.com" || hostname.endsWith(".suno.com");
  } catch {
    return false;
  }
}

function tokenExpiryLabel(token) {
  try {
    const payloadPart = token.split(".")[1];
    const normalized = payloadPart.replaceAll("-", "+").replaceAll("_", "/");
    const payload = JSON.parse(atob(normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=")));
    if (!Number.isFinite(payload.exp)) return "";
    const minutes = Math.max(0, Math.floor((payload.exp * 1000 - Date.now()) / 60000));
    return minutes > 0 ? ` It expires in about ${minutes} min.` : " It is already expired.";
  } catch {
    return "";
  }
}

function isTokenFresh(token, minMinutesLeft = 2) {
  try {
    const payloadPart = token.split(".")[1];
    const normalized = payloadPart.replaceAll("-", "+").replaceAll("_", "/");
    const payload = JSON.parse(atob(normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=")));
    if (!Number.isFinite(payload.exp)) return false;
    return payload.exp * 1000 - Date.now() > minMinutesLeft * 60 * 1000;
  } catch {
    return false;
  }
}

/** Read last Bearer captured by the content-script sniffer. */
async function getStoredBearer() {
  const data = await chrome.storage.local.get(["sunoBearer", "sunoBearerAt"]);
  if (!data.sunoBearer || typeof data.sunoBearer !== "string") return null;
  if (!data.sunoBearer.startsWith("eyJ")) return null;
  // Accept even if close to expiry — WAVD will use it immediately
  if (!isTokenFresh(data.sunoBearer, 0)) return null;
  return data.sunoBearer;
}

/** Read __client cookie from auth.suno.com (HttpOnly — only extension can read it). */
async function getClerkClientCookie() {
  try {
    const cookie = await chrome.cookies.get({
      url: "https://auth.suno.com",
      name: "__client",
    });
    if (cookie?.value) return cookie.value;

    // Fallback: sometimes stored under .suno.com
    const all = await chrome.cookies.getAll({ name: "__client" });
    const match = all.find(
      (c) =>
        c.domain.includes("suno.com") &&
        c.value &&
        c.value.length > 20
    );
    return match?.value || null;
  } catch {
    return null;
  }
}

/**
 * Exchange long-lived __client cookie for a short-lived session JWT
 * (same flow the browser / other tools use).
 */
async function mintJwtFromClientCookie(clientCookie) {
  const clientUrl =
    `${CLERK_BASE}/v1/client?__clerk_api_version=${CLERK_API_VERSION}` +
    `&_clerk_js_version=${CLERK_JS_VERSION}`;

  const clientRes = await fetch(clientUrl, {
    method: "GET",
    headers: {
      Authorization: clientCookie,
      Cookie: `__client=${clientCookie}`,
      Origin: "https://suno.com",
      Referer: "https://suno.com/",
      Accept: "application/json",
    },
  });

  if (!clientRes.ok) {
    throw new Error(`Clerk /v1/client failed (${clientRes.status}). Try signing in again on suno.com.`);
  }

  const clientBody = await clientRes.json();
  const response = clientBody.response || clientBody;

  let sessionId =
    response.last_active_session_id ||
    (Array.isArray(response.sessions) && response.sessions[0]?.id) ||
    null;

  if (!sessionId) {
    throw new Error("No active Clerk session. Open suno.com, sign in, then try again.");
  }

  const tokenUrl =
    `${CLERK_BASE}/v1/client/sessions/${sessionId}/tokens` +
    `?__clerk_api_version=${CLERK_API_VERSION}&_clerk_js_version=${CLERK_JS_VERSION}`;

  const tokenRes = await fetch(tokenUrl, {
    method: "POST",
    headers: {
      Authorization: clientCookie,
      Cookie: `__client=${clientCookie}`,
      Origin: "https://suno.com",
      Referer: "https://suno.com/",
      Accept: "application/json",
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "",
  });

  if (!tokenRes.ok) {
    throw new Error(`Clerk token exchange failed (${tokenRes.status}). Re-login on suno.com.`);
  }

  const tokenBody = await tokenRes.json();
  const jwt = tokenBody.jwt || tokenBody.token || null;
  if (!jwt || !String(jwt).startsWith("eyJ")) {
    throw new Error("Clerk returned no JWT. Re-login on suno.com and try again.");
  }
  return String(jwt);
}

/** Scan localStorage / sessionStorage / document.cookie inside the page. */
async function scanPageStorage(tabId) {
  try {
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: () => {
        const found = [];
        const consider = (val) => {
          if (typeof val === "string" && val.startsWith("eyJ") && val.split(".").length === 3) {
            found.push(val);
          }
        };
        try {
          for (let i = 0; i < localStorage.length; i++) {
            consider(localStorage.getItem(localStorage.key(i)));
          }
        } catch (_) {}
        try {
          for (let i = 0; i < sessionStorage.length; i++) {
            consider(sessionStorage.getItem(sessionStorage.key(i)));
          }
        } catch (_) {}
        try {
          const cookies = document.cookie.split(";");
          for (const part of cookies) {
            const eq = part.indexOf("=");
            if (eq === -1) continue;
            const name = part.slice(0, eq).trim();
            const value = part.slice(eq + 1).trim();
            if (name === "__session" || name.includes("session")) consider(value);
            consider(value);
          }
        } catch (_) {}
        // Prefer tokens that look like session JWTs (have exp in the near future)
        for (const t of found) {
          try {
            const payload = JSON.parse(
              atob(t.split(".")[1].replaceAll("-", "+").replaceAll("_", "/"))
            );
            if (payload.exp && payload.exp * 1000 > Date.now()) return t;
          } catch (_) {}
        }
        return found[0] || null;
      },
    });
    return injection?.result || null;
  } catch {
    return null;
  }
}

async function obtainToken(tabId) {
  // 1. Token already captured by background sniffer while browsing
  const stored = await getStoredBearer();
  if (stored) return { token: stored, source: "network-sniffer" };

  // 2. Mint fresh JWT from HttpOnly __client cookie (most reliable)
  const clientCookie = await getClerkClientCookie();
  if (clientCookie) {
    const jwt = await mintJwtFromClientCookie(clientCookie);
    // Cache it so next click is instant
    await chrome.storage.local.set({ sunoBearer: jwt, sunoBearerAt: Date.now() });
    return { token: jwt, source: "clerk-cookie" };
  }

  // 3. Last resort: scan page storage
  const fromPage = await scanPageStorage(tabId);
  if (fromPage) {
    await chrome.storage.local.set({ sunoBearer: fromPage, sunoBearerAt: Date.now() });
    return { token: fromPage, source: "page-storage" };
  }

  return null;
}

async function sendTokenToWavd(token) {
  let response;
  try {
    response = await fetch(WAVD_TOKEN_BRIDGE, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-WAVD-Token-Helper": "1",
      },
      body: JSON.stringify({ token }),
    });
  } catch {
    return null;
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error || `WAVD Desktop rejected the token (${response.status}).`);
    error.bridgeReached = true;
    throw error;
  }
  return payload;
}

button.addEventListener("click", async () => {
  button.disabled = true;
  setStatus("Scanning for Suno session…");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !isSunoPage(tab.url)) {
      throw new Error("Wrong planet. Open a signed-in page on suno.com first.");
    }

    const result = await obtainToken(tab.id);
    if (!result?.token) {
      throw new Error(
        "No Suno session found. Open suno.com, make sure you are signed in, refresh the page once, wait 2–3 seconds, then click again."
      );
    }

    const { token, source } = result;
    const bridge = await sendTokenToWavd(token);
    if (bridge) {
      setStatus(
        `Token beamed (${source}). ${bridge.resumed ? "Experiment resumed." : "Stored securely."}${tokenExpiryLabel(token)}`,
        "success"
      );
    } else {
      await navigator.clipboard.writeText(token);
      setStatus(
        `WAVD Desktop is not listening. Token copied to clipboard (${source}).${tokenExpiryLabel(token)}`,
        "fallback"
      );
    }
  } catch (error) {
    setStatus(error?.message || "Could not transfer the token.", "error");
  } finally {
    button.disabled = false;
  }
});
