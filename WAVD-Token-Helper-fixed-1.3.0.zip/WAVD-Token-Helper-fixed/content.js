/**
 * Content script (isolated world).
 * 1. Injects injected.js into the page main world (CSP-safe via script src).
 * 2. Listens for captured Bearer tokens and stores them in chrome.storage.local.
 */

(function () {
  // Inject the main-world sniffer as an external script (inline scripts are blocked by Suno CSP)
  try {
    const s = document.createElement("script");
    s.src = chrome.runtime.getURL("injected.js");
    s.async = false;
    (document.documentElement || document.head || document.body).appendChild(s);
    s.onload = () => s.remove();
  } catch (_) {}

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== "WAVD_TOKEN_HELPER" || data.type !== "SUNO_BEARER") return;
    const token = data.token;
    if (typeof token !== "string" || !token.startsWith("eyJ")) return;

    chrome.storage.local.set({
      sunoBearer: token,
      sunoBearerAt: Date.now(),
    });
  });
})();
